import { AboutUsSection } from "../components/AboutUsSection";
import { Footer } from "../components/Footer";
import { HeaderSinAuth } from "../components/HeaderSinAuth";
import { MisionVisionSection } from "../components/MisionVisionSection";
import { WhereAreWeSection } from "../components/WhereAreWeSection";
import { WhoAreWeSection } from "../components/WhoAreWeSection";

export function AboutUsPage() {
  return (
    <>
      <HeaderSinAuth />
      <AboutUsSection />
      <WhoAreWeSection />
      <MisionVisionSection />
      <WhereAreWeSection />
      <Footer />
    </>
  );
}