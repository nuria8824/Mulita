import { InicioSinAuth } from '../components/InicioSinAuth';

export function Index() {
  return (
    <>
      <InicioSinAuth />
    </>
  );
}