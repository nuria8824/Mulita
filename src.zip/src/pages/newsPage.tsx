import { useNavigate } from "@tanstack/react-router";
import { useCallback } from "react";
import { Footer } from "../components/Footer";
import { HeaderSinAuth } from "../components/HeaderSinAuth";

export function NewsPage() {
  const navigate = useNavigate();
  
  const botonConoceMas = useCallback(() => {
    navigate({ to: '/' });
  }, [navigate]);

  return (
    <>
      <HeaderSinAuth />

      <div className="w-full bg-white overflow-hidden shrink-0 flex flex-col items-center justify-start py-0 px-4 md:px-16 lg:px-24 box-border relative gap-[41px] text-base text-white">
        <div className="flex flex-col items-center justify-start gap-[19px] z-[0] text-center text-xs text-[#6d758f]">
          <div className="w-16 relative h-16 opacity-[0]">
            <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-[#f1f3f7] border-[#6d758f] border-solid border-[1px] box-border" />
            <div className="absolute top-[42.97%] left-[23.44%] tracking-[0.08em] leading-[18px] uppercase font-semibold">64px</div>
          </div>
          <div className="w-[1108px] h-12 flex flex-row items-center justify-center text-left text-4xl text-[#003c71]">
            <div className="relative leading-10 font-extrabold">Noticias</div>
          </div>
          <div className="w-[465px] relative text-sm leading-[22px] text-left inline-block">Lorem ipsum dolor sit amet consectoli tur adipiscing elit semper dalar.</div>
          <div className="w-[87px] relative border-[#fedd00] border-solid border-t-[4px] box-border h-1" />
          {/* Contenedor de noticias modificado */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* News Card 1 */}
            <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-lg bg-white border-[#e1e4ed] border-solid border-[1px] overflow-hidden flex flex-col items-center justify-start">
              <img className="w-full relative h-[239.7px] object-contain" alt="" src="Image (Replace).png" />
              <div className="p-4 flex flex-col items-start justify-start w-full">
                <div className="text-xl leading-7 font-extrabold text-[#003c71]">Web design</div>
                <div className="text-sm leading-[22px] text-left mt-2">Lorem ipsum dolor sit amet consectoli tur adipiscing elit semper dalar.</div>
                <div className="flex flex-row items-center justify-start gap-1.5 cursor-pointer text-base text-[#003c71] mt-4" onClick={botonConoceMas}>
                  <div className="relative leading-[22px] font-semibold">Conocé más</div>
                  <img className="w-[15px] relative h-[15px] overflow-hidden shrink-0" alt="" src="Line Rounded/Arrow rigth.svg" />
                </div>
              </div>
            </div>
            {/* News Card 2 */}
            <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-lg bg-white border-[#e1e4ed] border-solid border-[1px] overflow-hidden flex flex-col items-center justify-start">
              <img className="w-full relative h-[239.7px] object-contain" alt="" src="Image (Replace).png" />
              <div className="p-4 flex flex-col items-start justify-start w-full">
                <div className="text-xl leading-7 font-extrabold text-[#003c71]">Web design</div>
                <div className="text-sm leading-[22px] text-left mt-2">Lorem ipsum dolor sit amet consectoli tur adipiscing elit semper dalar.</div>
                <div className="flex flex-row items-center justify-start gap-1.5 cursor-pointer text-base text-[#003c71] mt-4" onClick={botonConoceMas}>
                  <div className="relative leading-[22px] font-semibold">Conocé más</div>
                  <img className="w-[15px] relative h-[15px] overflow-hidden shrink-0" alt="" src="Line Rounded/Arrow rigth.svg" />
                </div>
              </div>
            </div>
            {/* News Card 3 */}
            <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-lg bg-white border-[#e1e4ed] border-solid border-[1px] overflow-hidden flex flex-col items-center justify-start">
              <img className="w-full relative h-[239.7px] object-contain" alt="" src="Image (Replace).png" />
              <div className="p-4 flex flex-col items-start justify-start w-full">
                <div className="text-xl leading-7 font-extrabold text-[#003c71]">Web design</div>
                <div className="text-sm leading-[22px] text-left mt-2">Lorem ipsum dolor sit amet consectoli tur adipiscing elit semper dalar.</div>
                <div className="flex flex-row items-center justify-start gap-1.5 cursor-pointer text-base text-[#003c71] mt-4" onClick={botonConoceMas}>
                  <div className="relative leading-[22px] font-semibold">Conocé más</div>
                  <img className="w-[15px] relative h-[15px] overflow-hidden shrink-0" alt="" src="Line Rounded/Arrow rigth.svg" />
                </div>
              </div>
            </div>
            {/* News Card 4 */}
            <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-lg bg-white border-[#e1e4ed] border-solid border-[1px] overflow-hidden flex flex-col items-center justify-start">
              <img className="w-full relative h-[239.7px] object-contain" alt="" src="Image (Replace).png" />
              <div className="p-4 flex flex-col items-start justify-start w-full">
                <div className="text-xl leading-7 font-extrabold text-[#003c71]">Web design</div>
                <div className="text-sm leading-[22px] text-left mt-2">Lorem ipsum dolor sit amet consectoli tur adipiscing elit semper dalar.</div>
                <div className="flex flex-row items-center justify-start gap-1.5 cursor-pointer text-base text-[#003c71] mt-4" onClick={botonConoceMas}>
                  <div className="relative leading-[22px] font-semibold">Conocé más</div>
                  <img className="w-[15px] relative h-[15px] overflow-hidden shrink-0" alt="" src="Line Rounded/Arrow rigth.svg" />
                </div>
              </div>
            </div>
            {/* News Card 5 */}
            <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-lg bg-white border-[#e1e4ed] border-solid border-[1px] overflow-hidden flex flex-col items-center justify-start">
              <img className="w-full relative h-[239.7px] object-contain" alt="" src="Image (Replace).png" />
              <div className="p-4 flex flex-col items-start justify-start w-full">
                <div className="text-xl leading-7 font-extrabold text-[#003c71]">Web design</div>
                <div className="text-sm leading-[22px] text-left mt-2">Lorem ipsum dolor sit amet consectoli tur adipiscing elit semper dalar.</div>
                <div className="flex flex-row items-center justify-start gap-1.5 cursor-pointer text-base text-[#003c71] mt-4" onClick={botonConoceMas}>
                  <div className="relative leading-[22px] font-semibold">Conocé más</div>
                  <img className="w-[15px] relative h-[15px] overflow-hidden shrink-0" alt="" src="Line Rounded/Arrow rigth.svg" />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="w-10 relative h-10 opacity-[0]">
          <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-[#f1f3f7] border-[#6d758f] border-solid border-[1px] box-border" />
          <div className="absolute top-[38.75%] left-[30%] tracking-[0.08em] leading-[18px] uppercase font-semibold">40</div>
        </div>
      </div>

      <Footer />
    </>
  );
};