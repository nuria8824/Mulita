import { useNavigate } from "@tanstack/react-router";
import { useCallback } from "react";

export function HeroSection() {
  const navigate = useNavigate();
  
  const botonComunidad = useCallback(() => {
    navigate({ to: '/' });
  }, [navigate]);

  const botonTienda = useCallback(() => {
    navigate({ to: '/' });
  }, [navigate]);

 return (
  <div className="w-[1440px] bg-white overflow-hidden flex flex-row items-center justify-between py-20 px-[167px] box-border relative gap-0 text-center">
    <div className="flex flex-col items-start justify-start z-[0]">
      <div className="relative text-5xl leading-9 font-extrabold text-[#003c71] text-left [text-shadow:0px_4px_4px_#fedd00]">Mulita</div>
      <div className="w-6 relative h-6 opacity-[0]">
        <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-[#f1f3f7] border-[#6d758f] border-solid border-[1px] box-border" />
        <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
      </div>
      <div className="w-[461.7px] relative text-base leading-6 text-left inline-block">Lorem ipsum dolor sit amet consectetur adipiscing eli mattis sit phasellus mollis sit aliquam sit nullam neque ultrices.</div>
      <div className="w-8 relative h-8 opacity-[0]">
        <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-[#f1f3f7] border-[#6d758f] border-solid border-[1px] box-border" />
        <div className="absolute top-[35.94%] left-[25%] tracking-[0.08em] leading-[18px] uppercase font-semibold">32</div>
      </div>
      <div className="flex flex-row items-start justify-start gap-4 text-sm text-white">
        <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-md bg-[#003c71] flex flex-row items-center justify-center py-3.5 px-[18px] gap-[3px] cursor-pointer" onClick={botonComunidad}>
          <div className="relative leading-5 font-semibold">Comunidad</div>
          <img className="w-3 relative h-3" alt="" src="Line Rounded/Arrow rigth.svg" />
        </div>
        <div className="rounded-md bg-[#f8faff] border-[#fedd00] border-solid border-[1px] flex flex-row items-center justify-center py-[15px] px-[18px] cursor-pointer text-[#003c71]" onClick={botonTienda}>
          <div className="relative leading-5 font-semibold">Ver Tienda</div>
        </div>
      </div>
    </div>
    <img className="w-[488px] relative max-h-full object-cover z-[1]" alt="" src="image 12.png" />
    <img className="w-[83px] absolute !!m-[0 important] top-[186px] left-[170.58px] h-px object-contain z-[2]" alt="" src="Line 7.svg" />
  </div>
 );
};