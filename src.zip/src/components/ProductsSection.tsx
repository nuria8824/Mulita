import { useNavigate } from "@tanstack/react-router";
import { useCallback } from "react";

export function ProductsSection() {
  const navigate = useNavigate();
  
  const botonComprar = useCallback(() => {
    navigate({ to: '/' });
  }, [navigate]);

  const botonCarrito = useCallback(() => {
    navigate({ to: '/' });
  }, [navigate]);

  const botonTienda = useCallback(() => {
    navigate({ to: '/' });
  }, [navigate]);

 return (
  <div className="w-full relative bg-white overflow-hidden text-center text-xs text-slategray font-inter flex flex-col items-center justify-start py-0 px-[167px] box-border gap-[41px]">
    <div className="flex flex-col items-center justify-start text-4xl">
      <div className="relative leading-10 font-extrabold text-[#003c71]">Productos Destacados</div>
      <div className="w-6 relative h-6 opacity-[0] text-xs">
        <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
        <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
      </div>
      <div className="w-[518.3px] relative text-lg leading-7 inline-block">Lorem ipsum dolor sit amet consectetur adipiscing elit tortor eu egestas morbi sem vulputate etiam facilisis.</div>
    </div>
    <div className="w-12 h-12 opacity-[0]">
      <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
      <div className="absolute top-[40.63%] left-[33.33%] tracking-[0.08em] leading-[18px] uppercase font-semibold">48</div>
    </div>
    <div className="flex flex-row items-start justify-start gap-[22px]">
      <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-lg bg-white border-gainsboro border-solid border-[1px] overflow-hidden flex flex-col items-center justify-start">
        <div className="w-[260px] relative h-[260px] text-sm">
          <img className="absolute top-[0px] left-[0px] w-[260px] h-[260px] object-cover" alt="" src="Image.png" />
          <div className="absolute top-[16px] right-[17.14px] shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-[3px] bg-white border-whitesmoke border-solid border-[1px] overflow-hidden flex flex-row items-start justify-end p-2.5">
            <div className="flex flex-row items-center justify-start">
              <div className="relative leading-5 font-semibold">$49.00</div>
            </div>
          </div>
        </div>
        <div className="w-6 relative h-6 opacity-[0]">
          <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
          <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
        </div>
        <div className="flex flex-col items-start justify-start text-left">
          <div className="relative text-lg leading-6 font-semibold text-[#003c71]">Smartphone</div>
          <div className="w-4 relative h-4 opacity-[0]">
            <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
          </div>
          <div className="w-[227px] relative text-sm leading-[22px] inline-block">Lorem ipsum dolor sit amet conse bolli tetur adipiscing.</div>
          <div className="w-6 relative h-6 opacity-[0] text-center">
            <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
            <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
          </div>
          <div className="self-stretch flex flex-row items-start justify-start gap-[9px] text-center text-white">
            <div className="flex-1 shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded bg-[#003c71] flex flex-row items-center justify-center p-3 cursor-pointer" onClick={botonComprar}>
              <div className="relative leading-[18px] font-semibold">Comprar</div>
            </div>
            <div className="flex-1 shadow-[0px_2px_6px_rgba(25,_33,_61,_0.14)] rounded bg-white flex flex-row items-center justify-center p-3 cursor-pointer text-slategray" onClick={botonCarrito}>
              <div className="relative leading-[18px] font-semibold">Carrito</div>
            </div>
          </div>
        </div>
        <div className="w-6 relative h-6 opacity-[0]">
          <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
          <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
        </div>
      </div>
      <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-lg bg-white border-gainsboro border-solid border-[1px] overflow-hidden flex flex-col items-center justify-start">
        <div className="w-[260px] relative h-[260px] text-sm">
          <img className="absolute top-[0px] left-[0px] w-[260px] h-[260px] object-cover" alt="" src="Image.png" />
          <div className="absolute top-[16px] right-[17.14px] shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-[3px] bg-white border-whitesmoke border-solid border-[1px] overflow-hidden flex flex-row items-start justify-end p-2.5">
            <div className="flex flex-row items-center justify-start">
              <div className="relative leading-5 font-semibold">$19.00</div>
            </div>
          </div>
        </div>
        <div className="w-6 relative h-6 opacity-[0]">
          <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
          <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
        </div>
        <div className="flex flex-col items-start justify-start text-left">
          <div className="relative text-lg leading-6 font-semibold text-[#003c71]">Laptop</div>
          <div className="w-4 relative h-4 opacity-[0]">
            <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
          </div>
          <div className="w-[227px] relative text-sm leading-[22px] inline-block">Lorem ipsum dolor sit amet conse bolli tetur adipiscing.</div>
          <div className="w-6 relative h-6 opacity-[0] text-center">
            <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
            <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
          </div>
          <div className="self-stretch flex flex-row items-start justify-start gap-[9px] text-center text-white">
            <div className="flex-1 shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded bg-[#003c71] flex flex-row items-center justify-center p-3 cursor-pointer" onClick={botonComprar}>
              <div className="relative leading-[18px] font-semibold">Comprar</div>
            </div>
            <div className="flex-1 shadow-[0px_2px_6px_rgba(25,_33,_61,_0.14)] rounded bg-white flex flex-row items-center justify-center p-3 cursor-pointer text-slategray" onClick={botonCarrito}>
              <div className="relative leading-[18px] font-semibold">Carrito</div>
            </div>
          </div>
        </div>
        <div className="w-6 relative h-6 opacity-[0]">
          <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
          <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
        </div>
      </div>
      <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-lg bg-white border-gainsboro border-solid border-[1px] overflow-hidden flex flex-col items-center justify-start">
        <div className="w-[260px] relative h-[260px] text-sm">
          <img className="absolute top-[0px] left-[0px] w-[260px] h-[260px] object-cover" alt="" src="Image.png" />
          <div className="absolute top-[16px] right-[17.14px] shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-[3px] bg-white border-whitesmoke border-solid border-[1px] overflow-hidden flex flex-row items-start justify-end p-2.5">
            <div className="flex flex-row items-center justify-start">
              <div className="relative leading-5 font-semibold">$29.00</div>
            </div>
          </div>
        </div>
        <div className="w-6 relative h-6 opacity-[0]">
          <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
          <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
        </div>
        <div className="flex flex-col items-start justify-start text-left">
          <div className="relative text-lg leading-6 font-semibold text-[#003c71]">Wireless Earbuds</div>
          <div className="w-4 relative h-4 opacity-[0]">
            <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
          </div>
          <div className="w-[227px] relative text-sm leading-[22px] inline-block">Lorem ipsum dolor sit amet conse bolli tetur adipiscing.</div>
          <div className="w-6 relative h-6 opacity-[0] text-center">
            <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
            <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
          </div>
          <div className="self-stretch flex flex-row items-start justify-start gap-[9px] text-center text-white">
            <div className="flex-1 shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded bg-[#003c71] flex flex-row items-center justify-center p-3 cursor-pointer" onClick={botonComprar}>
              <div className="relative leading-[18px] font-semibold">Comprar</div>
            </div>
            <div className="flex-1 shadow-[0px_2px_6px_rgba(25,_33,_61,_0.14)] rounded bg-white flex flex-row items-center justify-center p-3 cursor-pointer text-slategray" onClick={botonCarrito}>
              <div className="relative leading-[18px] font-semibold">Carrito</div>
            </div>
          </div>
        </div>
        <div className="w-6 relative h-6 opacity-[0]">
          <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
          <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
        </div>
      </div>
      <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-lg bg-white border-gainsboro border-solid border-[1px] overflow-hidden flex flex-col items-center justify-start">
        <div className="w-[260px] relative h-[260px] text-sm">
          <img className="absolute top-[0px] left-[0px] w-[260px] h-[260px] object-cover" alt="" src="Image.png" />
          <div className="absolute top-[16px] right-[17.14px] shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-[3px] bg-white border-whitesmoke border-solid border-[1px] overflow-hidden flex flex-row items-start justify-end p-2.5">
            <div className="flex flex-row items-center justify-start">
              <div className="relative leading-5 font-semibold">$199.00</div>
            </div>
          </div>
        </div>
        <div className="w-6 relative h-6 opacity-[0]">
          <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
          <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
        </div>
        <div className="flex flex-col items-start justify-start text-left">
          <div className="relative text-lg leading-6 font-semibold text-[#003c71]">Gaming Console</div>
          <div className="w-4 relative h-4 opacity-[0]">
            <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
          </div>
          <div className="w-[227px] relative text-sm leading-[22px] inline-block">Lorem ipsum dolor sit amet conse bolli tetur adipiscing.</div>
          <div className="w-6 relative h-6 opacity-[0] text-center">
            <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
            <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
          </div>
          <div className="self-stretch flex flex-row items-start justify-start gap-[9px] text-center text-white">
            <div className="flex-1 shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded bg-[#003c71] flex flex-row items-center justify-center p-3 cursor-pointer" onClick={botonComprar}>
              <div className="relative leading-[18px] font-semibold">Comprar</div>
            </div>
            <div className="flex-1 shadow-[0px_2px_6px_rgba(25,_33,_61,_0.14)] rounded bg-white flex flex-row items-center justify-center p-3 cursor-pointer text-slategray" onClick={botonCarrito}>
              <div className="relative leading-[18px] font-semibold">Carrito</div>
            </div>
          </div>
        </div>
        <div className="w-6 relative h-6 opacity-[0]">
          <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
          <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
        </div>
      </div>
    </div>
    <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-md bg-[#003c71] flex flex-row items-center justify-center py-3.5 px-[18px] cursor-pointer text-sm text-white" onClick={botonTienda}>
      <div className="relative leading-5 font-semibold">Ver todos los productos</div>
    </div>
    <div className="w-10 h-10 opacity-[0]">
      <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
      <div className="absolute top-[38.75%] left-[30%] tracking-[0.08em] leading-[18px] uppercase font-semibold">40</div>
    </div>
  </div>
 );
};