import { useNavigate } from "@tanstack/react-router";
import { useCallback } from "react";

export function HeaderSinAuth() {
  const navigate = useNavigate();
  
  const botonInicio = useCallback(() => {
    navigate({ to: '/' });
  }, [navigate]);

  const botonNoticias = useCallback(() => {
    navigate({ to: '/news' });
  }, [navigate]);

  const botonComunidad = useCallback(() => {
    navigate({ to: '/' });
  }, [navigate]);

  const botonTienda = useCallback(() => {
    navigate({ to: '/' });
  }, [navigate]);

  const botonSobreNosotros = useCallback(() => {
    navigate({ to: '/about-us' });
  }, [navigate]);

  const botonRegistro = useCallback(() => {
    navigate({ to: '/' });
  }, [navigate]);

  const botonLogin = useCallback(() => {
    navigate({ to: '/' });
  }, [navigate]);

  return (
    <>
      <header className="w-full bg-white text-sm text-[#003c71] flex items-center justify-between p-4 md:px-8">
        {/* Grupo Logo y Nombre */}
        <div className="flex items-center">
          <img className="w-[53px] h-[47px] object-cover mr-2" alt="" src="image 12.png" />
          <div className="text-[15px] leading-9 font-medium w-[85px] h-9">
            <p className="m-0">Mulita</p>
          </div>
        </div>
        
        {/* Menú de Navegación - se oculta en pantallas pequeñas con 'hidden' y se muestra en medianas con 'md:flex' */}
        <nav className="hidden md:flex flex-row items-center justify-center gap-[30px]">
          <div className="cursor-pointer text-[#fedd00]" onClick={botonInicio}>
            <b className="tracking-[0.2px]">Inicio</b>
          </div>
          <div className="cursor-pointer" onClick={botonNoticias}>
            <div className="tracking-[0.2px] font-medium">Noticias</div>
          </div>
          <div className="cursor-pointer" onClick={botonComunidad}>
            <div className="tracking-[0.2px] font-medium">Comunidad</div>
          </div>
          <div className="cursor-pointer" onClick={botonTienda}>
            <div className="tracking-[0.2px] font-medium">Tienda</div>
          </div>
          <div className="cursor-pointer" onClick={botonSobreNosotros}>
            <div className="tracking-[0.2px] font-medium">Sobre nosotros</div>
          </div>
        </nav>

        {/* Botones de Acción */}
        <div className="flex flex-row items-center gap-[18px]">
          <div className="rounded-[5px] bg-[#fedd00] border-[#fedd00] border-solid border-[1px] flex items-center py-2 px-[22px] cursor-pointer" onClick={botonRegistro}>
            <div className="tracking-[0.46px] font-medium">Registro</div>
          </div>
          <div className="rounded-[5px] bg-[#003e73] flex items-center py-2 px-[22px] cursor-pointer text-white" onClick={botonLogin}>
            <div className="tracking-[0.46px] font-medium">LogIn</div>
          </div>
        </div>
      </header>

      {/* Border Line */}
      <div className="w-full relative border-[#003c71] border-solid border-t-[3px] box-border h-[3px]" />
    </>
  );
};