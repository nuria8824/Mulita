export function WhereAreWeSection(){
  return (
    <div className="w-full relative bg-white flex flex-col items-center justify-start text-center text-4xl text-slategray font-inter">
      <div className="w-[1440px] bg-white overflow-hidden flex flex-col items-center justify-start py-20 px-[167px] box-border">
        <div className="flex flex-col items-center justify-start">
          <div className="relative leading-10 font-extrabold text-darkslateblue">¿Dónde Estamos?</div>
          <div className="w-6 relative h-6 opacity-[0] text-xs">
            <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
            <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
          </div>
          <div className="w-[488px] relative text-lg leading-7 inline-block">
            <p className="m-0">Lorem ipsum dolor sit amet consectetur adipiscing eli mattis sit phasellus mollis sit aliquam sit nullam.</p>
          </div>
        </div>
        <div className="w-[87px] relative border-gold border-solid border-t-[4px] box-border h-1" />
        <div className="w-12 relative h-12 opacity-[0] text-xs">
          <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
          <div className="absolute top-[40.63%] left-[33.33%] tracking-[0.08em] leading-[18px] uppercase font-semibold">48</div>
        </div>
        <div className="flex flex-row items-end justify-start gap-[22px]">
          <div className="flex flex-col items-start justify-start gap-[22px]">
            <img className="w-[354px] relative rounded-md h-[354px] overflow-hidden shrink-0 object-cover" alt="" src="Image (Replace).png" />
            <img className="w-[354px] relative rounded-md h-[354px] overflow-hidden shrink-0 object-cover" alt="" src="Image (Replace).png" />
          </div>
          <div className="flex flex-col items-start justify-start gap-[22px]">
            <img className="w-[354px] relative rounded-md h-[477px] overflow-hidden shrink-0 object-cover" alt="" src="Image (Replace).png" />
            <img className="w-[354px] relative rounded-md h-[231.1px] overflow-hidden shrink-0 object-cover" alt="" src="Image (Replace).png" />
          </div>
          <div className="flex flex-col items-start justify-start gap-[22px]">
            <img className="w-[354px] relative rounded-md h-[231.1px] overflow-hidden shrink-0 object-cover" alt="" src="Image (Replace).png" />
            <img className="w-[354px] relative rounded-md h-[468.7px] overflow-hidden shrink-0 object-cover" alt="" src="Image (Replace).png" />
          </div>
        </div>
      </div>
    </div>
  );
};
