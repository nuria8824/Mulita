import { useNavigate } from "@tanstack/react-router";
import { useCallback } from "react";

export function NewsSection() {
  const navigate = useNavigate();
  
  const botonConoceMas = useCallback(() => {
    navigate({ to: '/' });
  }, [navigate]);

  const botonNoticias = useCallback(() => {
    navigate({ to: '/' });
  }, [navigate]);

  return (
    <div className="w-full bg-white overflow-hidden shrink-0 flex flex-col items-center justify-start py-0 px-4 md:px-16 lg:px-24 box-border relative gap-[41px] text-base text-white">
      <div className="flex flex-col items-center justify-start gap-[19px] z-[0] text-center text-xs text-[#6d758f]">
        <div className="w-16 relative h-16 opacity-[0]">
          <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-[#f1f3f7] border-[#6d758f] border-solid border-[1px] box-border" />
          <div className="absolute top-[42.97%] left-[23.44%] tracking-[0.08em] leading-[18px] uppercase font-semibold">64px</div>
        </div>
        <div className="w-[1108px] h-12 flex flex-row items-center justify-center text-left text-4xl text-[#003c71]">
          <div className="relative leading-10 font-extrabold">Noticias</div>
        </div>
        <div className="w-[465px] relative text-sm leading-[22px] text-left inline-block">Lorem ipsum dolor sit amet consectoli tur adipiscing elit semper dalar.</div>
        <div className="w-[87px] relative border-[#fedd00] border-solid border-t-[4px] box-border h-1" />
        <div className="flex flex-row items-start justify-start gap-[22px]">
          {/* News Card 1 */}
          <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-lg bg-white border-[#e1e4ed] border-solid border-[1px] overflow-hidden flex flex-col items-center justify-start">
            <img className="w-[353.2px] relative rounded-t-lg rounded-b-none h-[239.7px] overflow-hidden shrink-0 object-contain" alt="" src="Image (Replace).png" />
            <div className="w-8 relative h-8 opacity-[0]">
              <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-[#f1f3f7] border-[#6d758f] border-solid border-[1px] box-border" />
              <div className="absolute top-[35.94%] left-[25%] tracking-[0.08em] leading-[18px] uppercase font-semibold">32</div>
            </div>
            <div className="flex flex-col items-start justify-start">
              <div className="w-[245.7px] relative text-xl leading-7 font-extrabold text-[#003c71] text-left inline-block">Web design</div>
              <div className="w-6 relative h-6 opacity-[0]">
                <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-[#f1f3f7] border-[#6d758f] border-solid border-[1px] box-border" />
                <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
              </div>
              <div className="w-[292.3px] relative text-sm leading-[22px] text-left inline-block">Lorem ipsum dolor sit amet consectoli tur adipiscing elit semper dalar.</div>
              <div className="w-6 relative h-6 opacity-[0]">
                <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-[#f1f3f7] border-[#6d758f] border-solid border-[1px] box-border" />
                <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
              </div>
              <div className="flex flex-row items-center justify-start gap-1.5 cursor-pointer text-base text-[#003c71]" onClick={botonConoceMas}>
                <div className="relative leading-[22px] font-semibold">Conocé más</div>
                <img className="w-[15px] relative h-[15px] overflow-hidden shrink-0" alt="" src="Line Rounded/Arrow rigth.svg" />
              </div>
            </div>
            <div className="w-10 relative h-10 opacity-[0]">
              <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-[#f1f3f7] border-[#6d758f] border-solid border-[1px] box-border" />
              <div className="absolute top-[38.75%] left-[30%] tracking-[0.08em] leading-[18px] uppercase font-semibold">40</div>
            </div>
          </div>
          {/* News Card 2 */}
          <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-lg bg-white border-[#e1e4ed] border-solid border-[1px] overflow-hidden flex flex-col items-center justify-start">
            <img className="w-[353.2px] relative rounded-t-lg rounded-b-none h-[239.7px] overflow-hidden shrink-0 object-contain" alt="" src="Image (Replace).png" />
            <div className="w-8 relative h-8 opacity-[0]">
              <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-[#f1f3f7] border-[#6d758f] border-solid border-[1px] box-border" />
              <div className="absolute top-[35.94%] left-[25%] tracking-[0.08em] leading-[18px] uppercase font-semibold">32</div>
            </div>
            <div className="flex flex-col items-start justify-start">
              <div className="w-[245.7px] relative text-xl leading-7 font-extrabold text-[#003c71] text-left inline-block">Web design</div>
              <div className="w-6 relative h-6 opacity-[0]">
                <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-[#f1f3f7] border-[#6d758f] border-solid border-[1px] box-border" />
                <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
              </div>
              <div className="w-[292.3px] relative text-sm leading-[22px] text-left inline-block">Lorem ipsum dolor sit amet consectoli tur adipiscing elit semper dalar.</div>
              <div className="w-6 relative h-6 opacity-[0]">
                <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-[#f1f3f7] border-[#6d758f] border-solid border-[1px] box-border" />
                <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
              </div>
              <div className="flex flex-row items-center justify-start gap-1.5 cursor-pointer text-base text-[#003c71]" onClick={botonConoceMas}>
                <div className="relative leading-[22px] font-semibold">Conocé más</div>
                <img className="w-[15px] relative h-[15px] overflow-hidden shrink-0" alt="" src="Line Rounded/Arrow rigth.svg" />
              </div>
            </div>
            <div className="w-10 relative h-10 opacity-[0]">
              <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-[#f1f3f7] border-[#6d758f] border-solid border-[1px] box-border" />
              <div className="absolute top-[38.75%] left-[30%] tracking-[0.08em] leading-[18px] uppercase font-semibold">40</div>
            </div>
          </div>
          {/* News Card 3 */}
          <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-lg bg-white border-[#e1e4ed] border-solid border-[1px] overflow-hidden flex flex-col items-center justify-start">
            <img className="w-[353.2px] relative rounded-t-lg rounded-b-none h-[239.7px] overflow-hidden shrink-0 object-contain" alt="" src="Image (Replace).png" />
            <div className="w-8 relative h-8 opacity-[0]">
              <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-[#f1f3f7] border-[#6d758f] border-solid border-[1px] box-border" />
              <div className="absolute top-[35.94%] left-[25%] tracking-[0.08em] leading-[18px] uppercase font-semibold">32</div>
            </div>
            <div className="flex flex-col items-start justify-start">
              <div className="w-[245.7px] relative text-xl leading-7 font-extrabold text-[#003c71] text-left inline-block">Web design</div>
              <div className="w-6 relative h-6 opacity-[0]">
                <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-[#f1f3f7] border-[#6d758f] border-solid border-[1px] box-border" />
                <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
              </div>
              <div className="w-[292.3px] relative text-sm leading-[22px] text-left inline-block">Lorem ipsum dolor sit amet consectoli tur adipiscing elit semper dalar.</div>
              <div className="w-6 relative h-6 opacity-[0]">
                <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-[#f1f3f7] border-[#6d758f] border-solid border-[1px] box-border" />
                <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
              </div>
              <div className="flex flex-row items-center justify-start gap-1.5 cursor-pointer text-base text-[#003c71]" onClick={botonConoceMas}>
                <div className="relative leading-[22px] font-semibold">Conocé más</div>
                <img className="w-[15px] relative h-[15px] overflow-hidden shrink-0" alt="" src="Line Rounded/Arrow rigth.svg" />
              </div>
            </div>
            <div className="w-10 relative h-10 opacity-[0]">
              <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-[#f1f3f7] border-[#6d758f] border-solid border-[1px] box-border" />
              <div className="absolute top-[38.75%] left-[30%] tracking-[0.08em] leading-[18px] uppercase font-semibold">40</div>
            </div>
          </div>
        </div>
      </div>
      <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-md bg-[#003c71] flex flex-row items-center justify-center py-3.5 px-[18px] cursor-pointer z-[1] text-center text-sm" onClick={botonNoticias}>
        <div className="relative leading-5 font-semibold">Ver todas las noticias</div>
      </div>
      <div className="w-10 relative h-10 opacity-[0]">
        <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-[#f1f3f7] border-[#6d758f] border-solid border-[1px] box-border" />
        <div className="absolute top-[38.75%] left-[30%] tracking-[0.08em] leading-[18px] uppercase font-semibold">40</div>
      </div>
    </div>
  );
};