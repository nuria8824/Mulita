import { useNavigate } from "@tanstack/react-router";
import { useCallback } from "react";

export function Footer() {
  const navigate = useNavigate();
  
  const botonInicio = useCallback(() => {
    navigate({ to: '/' });
  }, [navigate]);

  const botonNoticias = useCallback(() => {
    navigate({ to: '/news' });
  }, [navigate]);

  const botonComunidad = useCallback(() => {
    navigate({ to: '/' });
  }, [navigate]);

  const botonTienda = useCallback(() => {
    navigate({ to: '/' });
  }, [navigate]);

  const botonSobreNosotros = useCallback(() => {
    navigate({ to: '/about-us' });
  }, [navigate]);

  return (
    <div className="w-full bg-[#003c71] border-[#e1e4ed] border-solid border-t-[1px] box-border overflow-hidden flex flex-col items-center justify-start py-[72px] px-[167px] text-base text-white">
      <div className="max-w-[1106px] w-full flex flex-row items-start justify-between gap-5">
        {/* Footer - Column 1 */}
        <div className="h-[200px] flex flex-col items-start justify-start gap-4">
          <div className="text-[32px] font-semibold text-white">Mulita</div>
          <div className="w-[304px] relative text-base leading-6 text-white text-left inline-block">Lorem ipsum dolor sit amet consectetur adipiscing elit aliquam mauris sed ma</div>
          <div className="flex flex-row items-center justify-start text-sm text-[#003c71]" onClick={botonSobreNosotros}>
            <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-md bg-[#fedd00] flex flex-row items-center justify-center py-3.5 px-[18px] gap-[3px] cursor-pointer">
              <div className="relative leading-5 font-semibold">Conocé más</div>
              <img className="w-3 relative h-3" alt="" src="Line Rounded/Arrow rigth.svg" />
            </div>
          </div>
        </div>
        {/* Footer - Column 2 */}
        <div className="flex flex-col items-start justify-start gap-8">
          <div className="relative leading-[22px] font-semibold">Sobre nosotros</div>
          <div className="flex flex-col items-start justify-start gap-6 text-[#b4b9c9]">
            <div className="cursor-pointer" onClick={botonSobreNosotros}>¿Quiénes somos?</div>
            <div className="cursor-pointer" onClick={botonSobreNosotros}>Misión</div>
            <div className="cursor-pointer" onClick={botonSobreNosotros}>Visión</div>
            <div className="cursor-pointer" onClick={botonSobreNosotros}>¿Dónde estamos?</div>
          </div>
        </div>
        {/* Footer - Column 3 */}
        <div className="flex flex-col items-start justify-start gap-8">
          <div className="relative leading-[22px] font-semibold">Enlaces</div>
          <div className="flex flex-col items-start justify-start gap-6 text-[#b4b9c9]">
            <div className="cursor-pointer" onClick={botonInicio}>Inicio</div>
            <div className="cursor-pointer" onClick={botonNoticias}>Noticias</div>
            <div className="cursor-pointer" onClick={botonComunidad}>Comunidad</div>
            <div className="cursor-pointer" onClick={botonTienda}>Tienda</div>
          </div>
        </div>
        {/* Footer - Column 4 */}
        <div className="flex flex-col items-start justify-start gap-8">
          <div className="relative leading-[22px] font-semibold">Contacto</div>
          <div className="flex flex-col items-start justify-start gap-6 text-[#b4b9c9]">
            <div>Universidad Adventista del Plata</div>
            <div>Libertador San Martin, Entre Rios</div>
            <div>contacto@uap.edu.ar</div>
            <div>+54 9 3435 723461</div>
          </div>
        </div>
      </div>
    </div>
  );
};