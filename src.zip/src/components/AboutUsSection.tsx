export function AboutUsSection() {
  return (
    <div className="w-full relative bg-white flex flex-col items-center justify-start text-center text-xs text-slategray font-inter">
      <div className="w-[1440px] bg-white overflow-hidden flex flex-row items-center justify-between py-20 px-[167px] box-border gap-0">
        <div className="flex flex-col items-start justify-start">
          <div className="relative text-5xl leading-9 font-extrabold text-darkslateblue text-left">Sobre Nosotros</div>
          <div className="w-6 relative h-6 opacity-[0]">
            <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
            <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">24</div>
          </div>
          <div className="w-[461.7px] relative text-base leading-6 text-left inline-block">
            Lorem ipsum dolor sit amet consectetur adipiscing eli mattis sit phasellus mollis sit aliquam sit nullam neque ultrices.
          </div>
          <div className="w-8 relative h-8 opacity-[0]">
            <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
            <div className="absolute top-[35.94%] left-[25%] tracking-[0.08em] leading-[18px] uppercase font-semibold">32</div>
          </div>
          <div className="flex flex-row items-start justify-start gap-4 text-sm text-white">
            <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-md bg-darkslateblue flex flex-row items-center justify-center py-3.5 px-[18px]">
              <div className="relative leading-5 font-semibold">¿Quiénes Somos?</div>
            </div>
            <div className="rounded-md bg-white border-gold border-solid border-[1px] flex flex-row items-center justify-center py-[15px] px-[18px] text-darkslateblue">
              <div className="relative leading-5 font-semibold">¿Dónde estamos?</div>
            </div>
          </div>
        </div>
        <div className="w-[564px] relative rounded-lg bg-whitesmoke h-[452px] overflow-hidden shrink-0">
          <img className="absolute top-[calc(50%_-_33px)] left-[calc(50%_-_33px)] w-[66px] h-[66px] object-cover" alt="" src="Icon Square/Image.png" />
        </div>
      </div>
    </div>
  );
};
