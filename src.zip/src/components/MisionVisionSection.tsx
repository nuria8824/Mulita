export function MisionVisionSection() {
  return (
      <div className="w-full relative bg-white flex flex-col items-center justify-start text-left text-4xl text-darkslateblue font-inter">
        <div className="w-[1440px] bg-white overflow-hidden flex flex-col items-center justify-start py-20 px-[167px] box-border">
          <div className="flex flex-row items-end justify-start gap-6">
            <div className="flex flex-col items-start justify-start">
              <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-lg bg-white border-gainsboro border-solid border-[1px] flex flex-col items-start justify-start py-8 pl-8 pr-0">
                <div className="flex flex-col items-start justify-start">
                  <div className="w-[453.6px] relative leading-8 font-extrabold inline-block">
                    Misión
                  </div>
                  <div className="w-4 relative h-4 opacity-[0]">
                    <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
                  </div>
                  <div className="w-[476.1px] relative text-lg leading-7 text-slategray inline-block">
                    Lorem ipsum dalaracc lacus vel facilisis dolor sit amet
                    consecte tur adipiscing elit semper.
                  </div>
                </div>
                <div className="w-10 relative h-10 opacity-[0] text-center text-xs text-slategray">
                  <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
                  <div className="absolute top-[38.75%] left-[30%] tracking-[0.08em] leading-[18px] uppercase font-semibold">
                    40
                  </div>
                </div>
                <div className="w-[509px] relative rounded-tl-lg rounded-tr-none rounded-br-none rounded-bl-lg bg-whitesmoke h-[300px] overflow-hidden shrink-0">
                  <img
                    className="absolute top-[calc(50%_-_32.73px)] left-[calc(50%_-_32.99px)] w-[66px] h-[66px] object-cover opacity-[0.35]"
                    alt=""
                    src="Icon Square/Image.png"
                  />
                </div>
              </div>
            </div>
            <div className="shadow-[0px_1px_4px_rgba(25,_33,_61,_0.08)] rounded-lg bg-white border-gainsboro border-solid border-[1px] overflow-hidden flex flex-row items-start justify-start pt-8 px-8 pb-[43px] text-center text-xs text-slategray">
              <div className="flex flex-col items-center justify-start">
                <div className="w-[477px] relative rounded-lg bg-whitesmoke h-[305px] overflow-hidden shrink-0">
                  <img
                    className="absolute top-[calc(50%_-_47.04px)] left-[calc(50%_-_33.01px)] w-[66px] h-[66px] object-cover opacity-[0.35]"
                    alt=""
                    src="Icon Square/Image.png"
                  />
                </div>
                <div className="w-6 relative h-6 opacity-[0]">
                  <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
                  <div className="absolute top-[29.17%] left-[16.67%] tracking-[0.08em] leading-[18px] uppercase font-semibold">
                    24
                  </div>
                </div>
                <div className="flex flex-col items-start justify-start text-left text-4xl text-darkslateblue">
                  <div className="w-[453.6px] relative leading-8 font-extrabold inline-block">
                    Visión
                  </div>
                  <div className="w-4 relative h-4 opacity-[0]">
                    <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-whitesmoke border-slategray border-solid border-[1px] box-border" />
                  </div>
                  <div className="w-[476.1px] relative text-lg leading-7 text-slategray inline-block">
                    Lorem ipsum dalaracc lacus vel facilisis dolor sit amet
                    consecte tur adipiscing elit semper.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
  );
};