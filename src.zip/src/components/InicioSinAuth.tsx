import { HeaderSinAuth } from './HeaderSinAuth';
import { HeroSection } from './HeroSection';
import { NewsSection } from './NewsSection';
import { ProductsSection } from './ProductsSection';
import { Footer } from './Footer';

export function InicioSinAuth() {

  return (
    <div className="w-full relative bg-white flex flex-col items-center justify-start text-left text-xs text-[#6d758f] font-inter">
      <HeaderSinAuth />
      <HeroSection />
      <NewsSection />
      <ProductsSection />
      <Footer />

    </div>
  );
};