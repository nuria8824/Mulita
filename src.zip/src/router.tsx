import { createRouter, createRootRoute, createRoute } from "@tanstack/react-router";
import { App } from "./App";
import { Index } from "./pages";
import { NewsPage } from "./pages/newsPage";
import { AboutUsPage } from "./pages/aboutUsPage";
// import { Settings } from "./pages/Settings";
// import { AuthPage } from "./pages/Auth";

const rootRoute = createRootRoute({
  component: App,
});

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  component: Index,
  path: "/",
});

// const authRoute = createRoute({
//   getParentRoute: () => rootRoute,
//   path: "/auth",
//   component: AuthPage,
// });

const newsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/news",
  component: NewsPage,
});

const aboutUsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/about-us",
  component: AboutUsPage,
});

// const settingsRoute = createRoute({
//   getParentRoute: () => rootRoute,
//   path: "/settings",
//   component: Settings,
// });

const routeTree = rootRoute.addChildren([
  indexRoute,
  //authRoute,
  newsRoute,
  aboutUsRoute,
  //settingsRoute,
]);

export const router = createRouter({ routeTree });

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}