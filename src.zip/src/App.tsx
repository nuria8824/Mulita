// import { ToastContainer } from "./components/ToastContainer";
import { Outlet } from "@tanstack/react-router";


export function App() {  

  return (
    <>
      {/* <ToastContainer />       */}
      <Outlet />
    </>
  );
}

export default App;